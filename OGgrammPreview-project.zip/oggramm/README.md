# OGgramm Preview

A local-only Android preview of an iOS-inspired Telegram chat list. It is a visual prototype: no Telegram login, network access, real messages, calls, or notifications.

## Build APK in GitHub Actions
1. Create a new GitHub repository (for example `oggramm-preview`).
2. Upload the contents of this folder to the repository root (not the enclosing ZIP folder).
3. Open **Actions** and run **Build Android preview APK** (or push to `main`).
4. Open the successful workflow run, download the `OGgrammPreview-debug-apk` artifact, and extract `app-debug.apk`.
5. Transfer the APK to the Huawei phone and install it.

The build workflow produces a debug APK, signed with the standard debug key. Do not use this prototype for real Telegram credentials.
