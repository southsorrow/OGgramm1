package com.oggramm.mock;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().setStatusBarColor(android.graphics.Color.rgb(248,249,251));
  getWindow().setNavigationBarColor(android.graphics.Color.rgb(248,249,251));
  getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
  WebView web = new WebView(this);
  web.setBackgroundColor(android.graphics.Color.rgb(248,249,251));
  WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  web.loadUrl("file:///android_asset/index.html"); setContentView(web);
 }
}
